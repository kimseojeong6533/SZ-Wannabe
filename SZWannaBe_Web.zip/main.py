from flask import Flask, render_template,request
import os
import pandas as pd
import folium

def add_html(address):
    #스쿨존에 따라 위험도가 저장된 csv를 불러온 후 주소를 입력하면 그 위치의 위도와 경도, 위험도가 변수로 저장
    df_sz2=pd.read_csv('School_Randset2.csv')
    df_sz2=pd.DataFrame(df_sz2.iloc[:,1:])
    is_sz = df_sz2['대상시설명'] == address
    is_df = df_sz2[is_sz]
    add = is_df[['위도','경도']].values.tolist()
    risk = is_df[['위험도']].values.tolist()
    #변수로 저장된 값들을 folium을 사용하여 지도에 나타내줌
    sz_loc = add[0]
    map_schoolzone=folium.Map(location=sz_loc, zoom_start=17)
    folium.Circle(add[0],
                radius=150,
                popup='위험도 : ' + str(risk[0]),
                color='#3186cc',
                fill=True).add_to(map_schoolzone)
    #나타낸 지도를 html로 저장
    map_schoolzone.save('templates/address.html')

PEOPLE_FOLDER = os.path.join('templates')

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = PEOPLE_FOLDER

@app.route('/')
def show_index():
    return render_template("index.html")


@app.route('/post', methods=['POST'])
def post():
    value = request.form['add']
    add_html(value)
    return render_template("address.html")

@app.route('/get', methods=['get'])
def sz_map():
    return render_template("index_copy.html")




app.run(host='0.0.0.0', port=5000, debug=True)
